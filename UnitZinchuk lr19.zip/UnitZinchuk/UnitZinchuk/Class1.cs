﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace UnitZinchuk
{
    /// <summary>
    /// Клас для аналізу тексту.
    /// </summary>
    public static class analizText
    {
        /// <summary>
        /// Перевіряє, чи є символ роздільником (пробіл . , : ;).
        /// </summary>
        public static bool rozdilZnak(char c)
        {
            if (c == ' ' || c == '.' || c == ',' || c == ':' || c == ';')
                return true;
            else
                return false;
        }
        //...
    }

    /// <summary>
    /// Клас для коректного введення чисел.
    /// </summary>
    public static class corectInput
    {
        /// <summary>
        /// Введення дійсного числа. true - число введено, false - користувач відмовився.
        /// </summary>
        public static bool inputDouble(ref double x, string povidom)
        {
            string s;
            s = x.ToString();
        Povtor:
            s = Interaction.InputBox(povidom, "Введення", s);
            try
            {
                x = Convert.ToDouble(s);
            }
            catch (System.FormatException)
            {
                if (MessageBox.Show("Ви ввели не дійсне число.\n\nБажаєте повторити?", "Увага",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    goto Povtor;
                else
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Введення цілого числа. true - число введено, false - користувач відмовився.
        /// </summary>
        public static bool inputInt(ref int x, string povidom)
        {
            string s;
            s = x.ToString();
        Povtor:
            s = Interaction.InputBox(povidom, "Введення", s);
            try
            {
                x = Convert.ToInt32(s);
            }
            catch (Exception ex) when (ex is FormatException || ex is OverflowException)
            {
                if (MessageBox.Show("Ви ввели не ціле число.\n\nБажаєте повторити?", "Увага",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    goto Povtor;
                else
                    return false;
            }
            return true;
        }
        //...
    }
} //завершення опису простору імен