using System;
using System.Windows.Forms;
using UnitZinchuk;

namespace QuadLR
{
    public partial class Form1 : Form
    {
        Button btn = new Button { Text = "Розв'язати ax²+bx+c=0", Left = 10, Top = 10, Width = 200 };
        Label lbl = new Label { Left = 10, Top = 50, Width = 360, Height = 80 };

        public Form1()
        {
            InitializeComponent();
            Text = "ЛР: квадратне рівняння";
            Width = 400; Height = 200;
            Controls.Add(btn); Controls.Add(lbl);
            btn.Click += btn_Click;
        }

        void btn_Click(object sender, EventArgs e)
        {
            double a = 1, b = 0, c = 0;
            int k = 2;
            if (!corectInput.inputDouble(ref a, "Введіть a")) return;
            if (!corectInput.inputDouble(ref b, "Введіть b")) return;
            if (!corectInput.inputDouble(ref c, "Введіть c")) return;
            if (!corectInput.inputInt(ref k, "Скільки знаків після коми показати?")) return;

            if (a == 0)
            {
                lbl.Text = b == 0 ? "Це не рівняння" : "Лінійне: x = " + Math.Round(-c / b, k);
                return;
            }
            double d = b * b - 4 * a * c;
            if (d < 0) lbl.Text = "Дійсних коренів немає (D = " + Math.Round(d, k) + ")";
            else if (d == 0) lbl.Text = "Один корінь: x = " + Math.Round(-b / (2 * a), k);
            else lbl.Text = "x1 = " + Math.Round((-b + Math.Sqrt(d)) / (2 * a), k) +
                            "\nx2 = " + Math.Round((-b - Math.Sqrt(d)) / (2 * a), k);
        }
    }
}