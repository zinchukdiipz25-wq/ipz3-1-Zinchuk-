using System;
using System.Windows.Forms;
using UnitZinchuk;

namespace StringLR
{
    public partial class Form1 : Form
    {
        TextBox txt = new TextBox { Multiline = true, Left = 10, Top = 10, Width = 360, Height = 80 };
        Button btn = new Button { Text = "Порахувати слова", Left = 10, Top = 100, Width = 160 };
        Label lbl = new Label { Left = 10, Top = 135, Width = 360, Height = 40 };

        public Form1()
        {
            InitializeComponent();
            Text = "ЛР: обробка рядків";
            Width = 400; Height = 230;
            Controls.Add(txt); Controls.Add(btn); Controls.Add(lbl);
            btn.Click += btn_Click;
        }

        void btn_Click(object sender, EventArgs e)
        {
            string s = txt.Text;
            int words = 0;
            for (int i = 0; i < s.Length; i++)
                if (!analizText.rozdilZnak(s[i]) && (i == 0 || analizText.rozdilZnak(s[i - 1])))
                    words++;
            lbl.Text = "Кількість слів: " + words;
        }
    }
}