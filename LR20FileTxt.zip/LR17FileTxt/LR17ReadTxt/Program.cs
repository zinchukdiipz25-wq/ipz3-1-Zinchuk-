﻿using System;
using System.IO;
using System.Windows.Forms;

namespace LR17ReadTxt
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"C:\LR17_Zinchuk\Zinchuk.txt";

            if (!File.Exists(path))
            {
                MessageBox.Show("Файл з прізвищами письменників відсутній.\n\nЗчитування виконати неможливо",
                    "Увага!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            string[] writers = File.ReadAllLines(path);   // зчитування однією командою
            string res = "";
            for (int i = 0; i < writers.Length; i++)
                res += (i + 1).ToString() + ". " + writers[i] + "\n";

            MessageBox.Show("Перелік письменників:\n" + res, "Результати",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}