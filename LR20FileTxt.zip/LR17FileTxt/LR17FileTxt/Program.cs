﻿using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace LR17FileTxt
{
    class Program
    {
        static void Main(string[] args)
        {
            // Власна папка на жорсткому диску і файл: ім'я = прізвище, розширення txt
            string folder = @"C:\LR17_Zinchuk";
            string path = folder + @"\Zinchuk.txt";
            // Шлях на флеш-носії (змініть літеру диска на свою!)
            string flash = @"D:\Zinchuk.txt";

            string[] writers = new string[5];
            for (int i = 0; i < writers.Length; i++)
            {
            povtorI:
                writers[i] = Interaction.InputBox("Введіть прізвище " + (i + 1) + "-го письменника", "Введення");
                if (writers[i] == "")
                    if (MessageBox.Show("Прізвище не введено!\n\nБажаєте повторити?", "Увага!",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                        goto povtorI;
                    else
                        return;
            }

            Directory.CreateDirectory(folder);        // створити папку, якщо її ще немає
            File.WriteAllLines(path, writers);        // запис масиву у файл однією командою

            if (!Directory.Exists(Path.GetPathRoot(flash)))
            {
                MessageBox.Show("Флеш-носій не знайдено.\nПерегляньте літеру диска в коді.", "Увага!",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (File.Exists(flash))
                File.Delete(flash);
            File.Copy(path, flash);                   // копіювання на флешку програмно

            MessageBox.Show("Дані у файл збережено успішно", "Результати",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}